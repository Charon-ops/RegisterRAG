import sys

sys.path.append(f"{sys.path[0]}/..")

import os
import json
import re

from langchain_core.documents import Document

from embedding import BgeEmbedding

qa_json = os.path.join(os.path.dirname(__file__), "qas.json")

with open(qa_json, "r") as f:
    data = json.load(f)

response = []

for res in data:
    # pattern = r"answer:\s*(.*?)\s*(?:\n\w+:|$)"
    # text = res["response"]
    # if not text:
    #     response.append("")
    #     continue
    # match = re.search(pattern, text, re.S)
    # if match:
    #     response.append(match.group(1))
    #     print(match.group(1))
    response.append(res["recall_content"])

embedding = BgeEmbedding(router_path="http://localhost", port="10000")

embeds = []

for i, r in enumerate(response):
    print(f"Process {i+1}/{len(response)}")
    embed = embedding.embed_document(Document(page_content=r))
    embeds.append(embed)

with open(
    os.path.join(os.path.dirname(__file__), "content_embedding.json"),
    "w",
    encoding="UTF-8",
) as f:
    json.dump({"embeds": embeds}, f, ensure_ascii=False, indent=4)
