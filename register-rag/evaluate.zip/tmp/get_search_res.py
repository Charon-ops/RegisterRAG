import os
import json
import time

import sys

sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from websearch import BaiduCallback, ArxivCallback
from web_extract import FirecrawlExtractor

baidu_searcher = BaiduCallback()
arxiv_searcher = ArxivCallback(
    qwen_plus_api_key="sk-e18ba2465ede4b309afde5ef4de4882a",
    baidu_app_id="20230110001525993",
    secret_key="KZY_UYhS_I7sQ5THfvIy",
)

qas_path = os.path.join(os.path.dirname(__file__), "qas.json")

with open(qas_path, "r") as f:
    qas = json.load(f)

query = []

for qa in qas:
    query.append(qa["query"])

search_res = []

for i in range(len(query)):
    print(f"Process {i+1}/{len(query)}")
    baidu_res = baidu_searcher.search(
        query[i],
        max_res=3,
        extractor=FirecrawlExtractor(router_path="http://localhost", port="3002"),
    )
    arxiv_res = arxiv_searcher.search(query[i], max_res=2)
    search_res.append(baidu_res + arxiv_res)
    print(search_res[-1])
    time.sleep(5)

search_data = []

for i in range(len(query)):
    search_data.append(
        {
            "query": query[i],
            "search_res": [r.page_content for r in search_res[i]],
        }
    )


with open(
    os.path.join(os.path.dirname(__file__), "search_res.json"), "w", encoding="UTF-8"
) as f:
    json.dump(search_data, f, ensure_ascii=False, indent=4)
