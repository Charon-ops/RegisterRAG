import os
import time
import json
from http import HTTPStatus

import dashscope
from dashscope import Generation

dashscope.api_key = "sk-e18ba2465ede4b309afde5ef4de4882a"


def call_qwen(message):
    messages = [{"role": "user", "content": message}]
    responses = Generation.call(
        "qwen-plus",
        messages=messages,
        result_format="message",
        stream=False,
    )
    if "output" not in responses:
        print("Error: ", responses)
        time.sleep(5)
        print("Retry...")
        call_qwen(message)
    if responses.status_code == HTTPStatus.OK:
        output = responses["output"]["choices"][0]["message"]["content"]
        return output
    else:
        print("Error: ", responses)
        time.sleep(5)
        print("Retry...")
        call_qwen(message)


qas_path = os.path.join(os.path.dirname(__file__), "qas.json")

with open(qas_path, "r") as f:
    qas = json.load(f)

query = []

for qa in qas:
    query.append(qa["query"])

recall_json = os.path.join(os.path.dirname(__file__), "recall_res.json")

with open(recall_json, "r") as f:
    recall_res = json.load(f)

recall_content = recall_res["res"]

response = []

for i in range(len(query)):
    print(f"Process {i+1}/{len(query)}")
    prompt = f"""
根据所给问题和信息，请合理回答问题，并提出可能由初学者提出的问题，使用陈述句形式。请将每个前置知识分别列出。

问题：{query[i]}

相关文档内容：
{recall_content[i]}

你的回答应包含两个部分：回答（answer）和前置知识（pre_knowledge）。
下面是回答模板和示例：

模板：
answer: 对查询问题的回答
pre_knowledge:
前置知识项1
前置知识项2
前置知识项3

示例：
answer: 自然语言处理是计算机科学、人工智能和语言学的交叉领域，涉及到计算机对人类语言的处理。
pre_knowledge:
计算机科学
人工智能
语言学

注意：在'pre_knowledge'部分中，只需要列出相关知识的名称，无需进行解释。同时，每个前置知识之前不允许存在任何标号。
你只需要对提出的问题进行回复，不需要对初学者可能产生的问题进行回复。
"""

    # print("=" * 50)
    # print(prompt)
    # print("=" * 50)
    res = call_qwen(prompt)
    if res == "":
        print(f"Error: {prompt}")
        continue
    print(res)
    response.append({"query": query[i], "respinse": res})

with open("reg_recall_res.json", "w", encoding="UTF-8") as f:
    json.dump(response, f, ensure_ascii=False, indent=4)
