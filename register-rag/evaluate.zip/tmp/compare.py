import os
import json

from scipy.spatial.distance import cosine

base_dir = os.path.dirname(__file__)

qwen_with_recall_and_search_json = os.path.join(
    base_dir, "qwen_with_recall_and_search_res_embedding.json"
)

qwen_with_recall_json = os.path.join(base_dir, "qwen_with_recall_res_embedding.json")

qwen_with_no_recall_json = os.path.join(base_dir, "qwen_no_recall_res_embedding.json")

rag_recall_json = os.path.join(base_dir, "rag_recall_res_embedding.json")

rag_recall_with_zip_json = os.path.join(
    base_dir, "rag_recall_with_zip_res_embedding.json"
)

rag_recall_with_web_json = os.path.join(
    base_dir, "rag_recall_with_web_res_embedding.json"
)

qas_json = os.path.join(base_dir, "qas.json")

with open(qwen_with_recall_and_search_json, "r") as f:
    qwen_with_recall_and_search_res = json.load(f)["embeds"]

with open(qwen_with_recall_json, "r") as f:
    qwen_with_recall_res = json.load(f)["embeds"]

with open(qwen_with_no_recall_json, "r") as f:
    qwen_with_no_recall_res = json.load(f)["embeds"]

with open(rag_recall_json, "r") as f:
    rag_recall_res = json.load(f)["embeds"]

with open(rag_recall_with_zip_json, "r") as f:
    rag_recall_with_zip_res = json.load(f)["embeds"]

with open(rag_recall_with_web_json, "r") as f:
    rag_recall_with_web_res = json.load(f)["embeds"]

with open(qas_json, "r") as f:
    qas = json.load(f)

no_recall_sim = 0.0
with_recall_sim = 0.0
rag_recall_sim = 0.0
rag_recall_with_zip_sim = 0.0
rag_recall_with_web_sim = 0.0

for i in range(len(qwen_with_recall_and_search_res)):
    no_recall = 1 - cosine(
        qwen_with_recall_and_search_res[i], qwen_with_no_recall_res[i]
    )
    with_recall = 1 - cosine(
        qwen_with_recall_and_search_res[i], qwen_with_recall_res[i]
    )
    rag_recall = 1 - cosine(qwen_with_recall_and_search_res[i], rag_recall_res[i])
    rag_recall_with_zip = 1 - cosine(
        qwen_with_recall_and_search_res[i], rag_recall_with_zip_res[i]
    )
    rag_recall_with_web = 1 - cosine(
        qwen_with_recall_and_search_res[i], rag_recall_with_web_res[i]
    )

    no_recall_sim += no_recall / len(qwen_with_recall_and_search_res)
    with_recall_sim += with_recall / len(qwen_with_recall_and_search_res)
    rag_recall_sim += rag_recall / len(qwen_with_recall_and_search_res)
    rag_recall_with_zip_sim += rag_recall_with_zip / len(
        qwen_with_recall_and_search_res
    )
    rag_recall_with_web_sim += rag_recall_with_web / len(
        qwen_with_recall_and_search_res
    )

print(f"No recall similarity: {no_recall_sim}")
print(f"With recall similarity: {with_recall_sim}")
print(f"Rag recall similarity: {rag_recall_sim}")
print(f"Rag recall with zip similarity: {rag_recall_with_zip_sim}")
print(f"Rag recall with web similarity: {rag_recall_with_web_sim}")

content_embedding_json = os.path.join(
    os.path.dirname(__file__), "content_embedding.json"
)
with open(content_embedding_json, "r") as f:
    content_embedding = json.load(f)["embeds"]

no_recall_with_content_sim = 0.0
with_recall_with_content_sim = 0.0
rag_recall_with_content_sim = 0.0

for i in range(len(qwen_with_recall_and_search_res)):
    no_recall_with_content = 1 - cosine(
        qwen_with_no_recall_res[i], content_embedding[i]
    )
    # with_recall_with_content = 1 - cosine(qwen_with_recall_res[i], content_embedding[i])
    rag_recall_with_content = 1 - cosine(rag_recall_res[i], content_embedding[i])

    no_recall_with_content_sim += no_recall_with_content / len(
        qwen_with_recall_and_search_res
    )
    # with_recall_with_content_sim += with_recall_with_content / len(
    #     qwen_with_recall_and_search_res
    # )
    rag_recall_with_content_sim += rag_recall_with_content / len(
        qwen_with_recall_and_search_res
    )

print(f"No recall with content similarity: {no_recall_with_content_sim}")
# print(f"With recall with content similarity: {with_recall_with_content_sim}")
print(f"Rag recall with content similarity: {rag_recall_with_content_sim}")
