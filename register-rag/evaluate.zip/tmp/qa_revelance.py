import sys

sys.path.append(f"{sys.path[0]}/..")

import os
import json

from scipy.spatial.distance import cosine
from langchain_core.documents import Document

from embedding import BgeEmbedding

embedding = BgeEmbedding(router_path="http://localhost", port="10000")

query = []
with open(os.path.join(os.path.dirname(__file__), "qas.json"), "r") as f:
    qas = json.load(f)
for qa in qas:
    query.append(qa["query"])

query_embedding = embedding.embed_documents([Document(page_content=q) for q in query])

generation_json = os.path.join(os.path.dirname(__file__), "generation_res.json")
with open(generation_json, "r") as f:
    generation_res = json.load(f)["res"]

generation_embedding = embedding.embed_documents(
    [Document(page_content=r) for r in generation_res]
)

similarity = 0.0
for i in range(len(query)):
    print(f"Process {i+1}/{len(query)}")
    sim = 1 - cosine(query_embedding[i], generation_embedding[i])
    print(f"Similarity: {sim}")
    similarity += sim / len(query)

print(f"Average similarity: {similarity}")
