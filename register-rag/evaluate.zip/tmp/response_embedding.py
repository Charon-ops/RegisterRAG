import sys

sys.path.append(f"{sys.path[0]}/..")

import os
import json
import re

from langchain_core.documents import Document

from embedding import BgeEmbedding

# json_file = os.path.join(
#     os.path.dirname(__file__), "qwen_with_recall_and_search_res.json"
# )  # done

# json_file = os.path.join(os.path.dirname(__file__), "qwen_no_recall_res.json")  # done

# json_file = os.path.join(os.path.dirname(__file__), "qwen_with_recall_res.json")  # done

# json_file = os.path.join(os.path.dirname(__file__), "rag_recall_res.json")  # done

# json_file = os.path.join(
#     os.path.dirname(__file__), "rag_recall_with_zip_res.json"
# )  # done

json_file = os.path.join(
    os.path.dirname(__file__), "rag_recall_with_web_res.json"
)  # done

with open(json_file, "r") as f:
    qwen_with_no_recall_res = json.load(f)

response = []

for res in qwen_with_no_recall_res:
    pattern = r"answer:\s*(.*?)\s*(?:\n\w+:|$)"
    text = res["response"]
    if not text:
        response.append("")
        continue
    match = re.search(pattern, text, re.S)
    if match:
        response.append(match.group(1))
        print(match.group(1))

embedding = BgeEmbedding(router_path="http://localhost", port="10000")

embeds = []

for i, r in enumerate(response):
    print(f"Process {i+1}/{len(response)}")
    embed = embedding.embed_document(Document(page_content=r))
    embeds.append(embed)

with open(
    os.path.join(
        os.path.dirname(__file__), f"{json_file.split('.')[0]}_embedding.json"
    ),
    "w",
    encoding="UTF-8",
) as f:
    json.dump({"embeds": embeds}, f, ensure_ascii=False, indent=4)
