import os
import json
from datasketch import MinHash


def calculate_minhash_similarity(str1, str2, num_perm=128):
    m1, m2 = MinHash(num_perm=num_perm), MinHash(num_perm=num_perm)

    for d in str1:
        m1.update(d.encode("utf8"))
    for d in str2:
        m2.update(d.encode("utf8"))

    return m1.jaccard(m2)


generation_json = os.path.join(os.path.dirname(__file__), "generation_res.json")
with open(generation_json, "r") as f:
    generation_res = json.load(f)["res"]

answer_json = os.path.join(os.path.dirname(__file__), "qas.json")
answer_res = []
with open(answer_json, "r") as f:
    qas = json.load(f)
    qa_response = [qa["response"] for qa in qas]

    for r in qa_response:
        start = r.find("问题回答：") + len("问题回答：")
        answer_res.append(r[start:].strip())

similarity = 0.0
for i in range(len(generation_res)):
    print(f"Process {i+1}/{len(generation_res)}")
    sim = calculate_minhash_similarity(generation_res[i], answer_res[i])
    print(f"Similarity: {sim}")
    similarity += sim / len(generation_res)

print(f"Average similarity: {similarity}")
