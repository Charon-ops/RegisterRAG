import os
import json

with open(os.path.join(os.path.dirname(__file__), "recall_res.json"), "r") as f:
    data = json.load(f)


with open(
    os.path.join(os.path.dirname(__file__), "recall_res.json"), "w", encoding="UTF-8"
) as f:
    json.dump(data, f, ensure_ascii=False, indent=4)
